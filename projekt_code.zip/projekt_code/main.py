import sys, logging
from PyQt5.QtWidgets import QApplication
from login import LoginWindow
from senzor import SensorThread

if __name__ == '__main__':
    logging.basicConfig(level=logging.INFO,
                        format='%(asctime)s %(levelname)s: %(message)s')

    app = QApplication(sys.argv)

    sensor_thread = SensorThread(poll_interval=60)
    sensor_thread.started.connect(lambda: logging.info("SensorThread started"))
    sensor_thread.finished.connect(lambda: logging.info("SensorThread finished"))
    sensor_thread.start()

    window = LoginWindow()
    window.show()
    exit_code = app.exec_()

    # now that the Qt loop has exited, stop & wait for the thread
    sensor_thread.stop()
    sensor_thread.wait()
    logging.info("SensorThread finished") 
    sys.exit(exit_code)