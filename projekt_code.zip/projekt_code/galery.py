import os
import requests
from PyQt5.QtWidgets import (
     QWidget, QVBoxLayout, QHBoxLayout, QComboBox,
     QPushButton, QScrollArea, QLabel, QGridLayout,
     QFrame, QDialog, QSizePolicy, QFileDialog, QMessageBox
 )
from PyQt5.QtGui import QPixmap
from PyQt5.QtCore import Qt, pyqtSignal
from db import get_db_connection
from utils import fetch_plants, fetch_recent_photos, load_plant_pixmap

class HoverLabel(QLabel):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.caption = None
        self.setMouseTracking(True)

    def setCaption(self, caption_lbl):
        self.caption = caption_lbl

    def enterEvent(self, ev):
        if self.caption:
            self.caption.show()
        super().enterEvent(ev)

    def leaveEvent(self, ev):
        if self.caption:
            self.caption.hide()
        super().leaveEvent(ev)

class GalleryWidget(QWidget):
    def __init__(self, user_id, parent=None):
        super().__init__(parent)
        self.user_id = user_id
        self.view_mode = 'grid'
        self.photos = []
        self.initUI()
        self.load_plants()
        self.load_photos()

    def initUI(self):
        layout = QVBoxLayout(self)

        # Top controls: plant filter, sort, view toggle
        ctrl = QHBoxLayout()
        self.plant_filter = QComboBox()
        self.plant_filter.addItem("All plants", None)
        self.plant_filter.currentIndexChanged.connect(self.load_photos)
        ctrl.addWidget(self.plant_filter)

        self.sort_combo = QComboBox()
        self.sort_combo.addItem("Date ↓", Qt.DescendingOrder)
        self.sort_combo.addItem("Date ↑", Qt.AscendingOrder)
        self.sort_combo.currentIndexChanged.connect(self.load_photos)
        ctrl.addWidget(self.sort_combo)

        self.view_btn = QPushButton("List View")
        self.view_btn.clicked.connect(self.toggle_view)
        ctrl.addWidget(self.view_btn)
        ctrl.addStretch()
        layout.addLayout(ctrl)

        # Scrollable photo area
        self.scroll = QScrollArea()
        self.scroll.setWidgetResizable(True)
        self.scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        self.scroll.setVerticalScrollBarPolicy(Qt.ScrollBarAsNeeded)

        self.container = QWidget()
        self.grid = QGridLayout(self.container)
        self.grid.setSpacing(8)
        self.scroll.setWidget(self.container)
        layout.addWidget(self.scroll)

    def load_plants(self):
        plants = self.get_user_plants(self.user_id)
        for p in plants:
            self.plant_filter.addItem(p['name'], p['id'])

    def load_photos(self):
        # clear old …
        while self.grid.count():
            item = self.grid.takeAt(0)
            if item.widget(): item.widget().setParent(None)

        photos = self.get_recent_photos(self.user_id, 100)
        pid = self.plant_filter.currentData()
        if pid:
            photos = [p for p in photos if p['plant_id'] == pid]
        order = self.sort_combo.currentData()
        photos.sort(key=lambda x: x['date_added'],
                    reverse=(order == Qt.DescendingOrder))

        if self.view_mode == 'grid':
            cols = 3
            self.grid.setSpacing(12)
            for i, p in enumerate(photos):
                frame = QFrame()
                v = QVBoxLayout(frame)
                v.setContentsMargins(6, 6, 6, 6)
                v.setSpacing(4)

                # load pixmap (local or remote)
                pixmap = QPixmap()
                path = p['filepath']
                if os.path.isfile(path):
                    pixmap.load(path)
                else:
                    try:
                        resp = requests.get(path, timeout=5)
                        resp.raise_for_status()
                        pixmap.loadFromData(resp.content)
                    except:
                        pixmap = load_plant_pixmap(p['plant_id'])

                v.setContentsMargins(10, 10, 10, 10)
                v.setSpacing(8)

                thumb = pixmap.scaled(250, 250,
                          Qt.KeepAspectRatio,
                          Qt.SmoothTransformation)
                
                # ↓ use HoverLabel instead of QLabel
                img = HoverLabel()
                img.setPixmap(thumb)
                img.setAlignment(Qt.AlignCenter)
                img.mousePressEvent = lambda ev, pp=p: self.open_fullscreen(pp)

                # now create a small caption QLabel underneath…
                caption = QLabel(
                    f"{p['plant_name']}\n"
                    f"{p['date_added'].strftime('%Y-%m-%d %H:%M')}",
                    frame
                )
                caption.setStyleSheet(
                    "background: rgba(0,0,0,0.7);"
                    "color: white;"
                    "padding: 8px;"         # padding around text
                    "font-size: 16px;"      # larger text
                )
                caption.setAlignment(Qt.AlignCenter)
                # make it shrink‐wrap its text
                caption.setSizePolicy(QSizePolicy.Fixed, QSizePolicy.Fixed)
                caption.adjustSize()
                caption.setFixedSize(caption.sizeHint())

                caption.hide()

                # wire them up
                img.setCaption(caption)

                # add to layout
                v.addWidget(img)
                v.addWidget(caption, alignment=Qt.AlignHCenter)

                # enable hover on frame too (optional)
                frame.setMouseTracking(True)
                frame.setAttribute(Qt.WA_Hover, True)

                r, c = divmod(i, cols)
                self.grid.addWidget(frame, r, c)

        else:
            # fully‐fleshed “list” view: horizontal frames
            self.grid.setSpacing(8)
            for i, p in enumerate(photos):
                frame = QFrame()
                h = QHBoxLayout(frame)
                h.setContentsMargins(6, 6, 6, 6)
                h.setSpacing(8)

                # load pixmap (local or remote)
                pixmap = QPixmap()
                path = p['filepath']
                if os.path.isfile(path):
                    pixmap.load(path)
                else:
                    try:
                        resp = requests.get(path, timeout=5)
                        resp.raise_for_status()
                        pixmap.loadFromData(resp.content)
                    except:
                        pixmap = load_plant_pixmap(p['plant_id'])

                thumb = pixmap.scaled(200, 200,
                                      Qt.KeepAspectRatio,
                                      Qt.SmoothTransformation)
                img = QLabel()
                img.setPixmap(thumb)
                img.setAlignment(Qt.AlignCenter)
                img.mousePressEvent = lambda ev, pp=p: self.open_fullscreen(pp)
                h.addWidget(img)

                info = QVBoxLayout()
                name_lbl = QLabel(p['plant_name'])
                name_lbl.setStyleSheet("font-size:14px; font-weight:bold;")
                date_lbl = QLabel(p['date_added'].strftime('%Y-%m-%d %H:%M'))
                date_lbl.setStyleSheet("font-size:12px; color:gray;")
                info.addWidget(name_lbl)
                info.addWidget(date_lbl)
                info.addStretch()
                h.addLayout(info)

                self.grid.addWidget(frame, i, 0)

        self.container.adjustSize()

    def toggle_view(self):
        if self.view_mode=='grid':
            self.view_mode='list'; self.view_btn.setText("Grid View")
        else:
            self.view_mode='grid'; self.view_btn.setText("List View")
        self.load_photos()

    def open_fullscreen(self, photo):
        dlg = QDialog(self)
        dlg.setWindowTitle(photo['plant_name'])
        # resize dialog to 90% of main-window
        main = self.window().frameGeometry().size()
        dlg.resize(int(main.width() * 0.9),
                   int(main.height()* 0.9))

        # load the “original” pixmap – local or remote
        original = QPixmap()
        path = photo['filepath']
        if os.path.isfile(path):
            original.load(path)
        else:
            try:
                resp = requests.get(path, timeout=5)
                resp.raise_for_status()
                original.loadFromData(resp.content)
            except Exception:
                # fallback placeholder
                original = load_plant_pixmap(photo['plant_id'])

        # scale it down to fit dialog
        thumb = original.scaled(
            dlg.size(),
            Qt.KeepAspectRatio,
            Qt.SmoothTransformation
        )

        v = QVBoxLayout(dlg)
        lbl = QLabel()
        lbl.setPixmap(thumb)
        lbl.setAlignment(Qt.AlignCenter)
        v.addWidget(lbl)

        dlg.exec_()
       

    def get_recent_photos(self, user_id, limit):
        return fetch_recent_photos(user_id, limit)

    def get_user_plants(self, user_id):
        return [
            {'id': p['id'], 'name': p['naziv']}
            for p in fetch_plants(user_id)
        ]


class AddPhotoWindow(QWidget):
    photo_added = pyqtSignal()

    def __init__(self, user_id):
        super().__init__()
        self.user_id = user_id
        self.pics = []
        self.initUI()

    def initUI(self):
        self.setWindowTitle("Dodaj sliku")
        v = QVBoxLayout(self)

        # Plant selector
        v.addWidget(QLabel("Biljka:", self))
        self.plant_combo = QComboBox(self)
        for p in fetch_plants(self.user_id):
            self.plant_combo.addItem(p['naziv'], p['id'])
        v.addWidget(self.plant_combo)

        # Select photos
        btn_pic = QPushButton("Odaberi slike…", self)
        btn_pic.clicked.connect(self.select_pics)
        v.addWidget(btn_pic)

        # Save button
        btn_save = QPushButton("Spremi", self)
        btn_save.clicked.connect(self.save)
        v.addWidget(btn_save)

    def select_pics(self):
        files, _ = QFileDialog.getOpenFileNames(
            self, "Odaberi slike", "", "Images (*.png *.jpg *.jpeg)"
        )
        if files:
            self.pics.extend(files)

    def save(self):
        pid = self.plant_combo.currentData()
        if not self.pics:
            QMessageBox.warning(self, "Error", "Odaberite barem jednu sliku")
            return

        conn = get_db_connection()
        cur = conn.cursor()
        for url in self.pics:
            cur.execute(
                "INSERT INTO slika(biljka_id, url) VALUES (%s, %s)",
                (pid, url)
            )
        conn.commit()
        cur.close()
        conn.close()

        self.photo_added.emit()
        self.close()