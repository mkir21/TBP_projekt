from PyQt5.QtWidgets import (
    QWidget, QLabel, QLineEdit, QPushButton, QVBoxLayout,
    QMessageBox
)
from PyQt5.QtGui import QFont, QPixmap
from PyQt5.QtCore import Qt
from db import get_db_connection
from main_window import MainWindow

class LoginWindow(QWidget):
    def __init__(self):
        super().__init__()
        self.initUI()

    def initUI(self):
        self.setWindowTitle('Bud-dy Prijava')
        self.setGeometry(100, 100, 600, 400)  # Set the window size

        self.image_label = QLabel(self)
        pixmap = QPixmap('logo.png')
        self.image_label.setPixmap(pixmap)

        self.title_label = QLabel('Bud-dy', self)
        font = QFont('PT Sans', 30)
        font.setItalic(True)
        self.title_label.setFont(font)
        self.title_label.setAlignment(Qt.AlignCenter)

        self.username_label = QLabel('Korisničko ime ili Email:', self)
        self.username_input = QLineEdit(self)
        self.username_input.returnPressed.connect(self.check_login)

        self.password_label = QLabel('Lozinka:', self)
        self.password_input = QLineEdit(self)
        self.password_input.setEchoMode(QLineEdit.Password)
        self.password_input.returnPressed.connect(self.check_login)

        self.login_button = QPushButton('Prijava', self)
        self.login_button.clicked.connect(self.check_login)

        layout = QVBoxLayout()
        layout.addWidget(self.image_label, alignment=Qt.AlignCenter)
        layout.addWidget(self.title_label, alignment=Qt.AlignCenter)
        layout.addWidget(self.username_label)
        layout.addWidget(self.username_input)
        layout.addWidget(self.password_label)
        layout.addWidget(self.password_input)
        layout.addWidget(self.login_button)

        self.setLayout(layout)

    def check_login(self):
        username = self.username_input.text()
        password = self.password_input.text()

        conn = None
        try:
            conn = get_db_connection()
            cur = conn.cursor()
            cur.execute("SELECT * FROM korisnik WHERE ime=%s OR email=%s", (username, username))
            user = cur.fetchone()
            if user:
                cur.execute("SELECT * FROM korisnik WHERE (ime=%s OR email=%s) AND password=%s", (username, username, password))
                result = cur.fetchone()
                if result:
                    user_id = result[0]
                    QMessageBox.information(self, 'Success', 'Login successful!')
                    self.open_dashboard(user_id)
                    self.close()
                else:
                    QMessageBox.warning(self, 'Error', 'Invalid password')
            else:
                QMessageBox.warning(self, 'Error', 'User does not exist')
            cur.close()
        except Exception as e:
            QMessageBox.critical(self, 'Error', str(e))
        finally:
            if conn:
                conn.close()

    def open_dashboard(self, user_id):
        self.dashboard = MainWindow(user_id)
        self.dashboard.show()
        self.close()