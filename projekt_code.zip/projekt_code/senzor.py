import time
import random
import logging
from PyQt5.QtCore import QThread
from datetime import datetime, timedelta
from psycopg2.extras import RealDictCursor
from db import get_db_connection

class SensorThread(QThread):
    def __init__(self, poll_interval=60):
        super().__init__()        # <-- QThread
        self.poll_interval = poll_interval
        self._running = True

    def run(self):
        conn = get_db_connection()
        conn.autocommit = True
        cur = conn.cursor(cursor_factory=RealDictCursor)
        try:
            while self._running:
                # 1) fetch all plant measurement settings
                cur.execute("""
                    SELECT biljka_id, interval_mjerenja, datum_postavljanja
                      FROM postavke_mjerenja
                """)
                settings = cur.fetchall()

                now = datetime.now()
                for s in settings:
                    biljka_id = s["biljka_id"]
                    interval_h = s["interval_mjerenja"]
                    start_ts  = s["datum_postavljanja"]

                    # 2) find last sensor reading
                    cur.execute("""
                        SELECT datum_mjerenja
                          FROM mjerenje_izvor
                         WHERE biljka_id = %s
                           AND izvor = 'senzor'
                         ORDER BY datum_mjerenja DESC
                         LIMIT 1
                    """, (biljka_id,))
                    last = cur.fetchone()
                    last_ts = last["datum_mjerenja"] if last else start_ts - timedelta(hours=interval_h)

                    # 3) insert if interval passed
                    if now >= (last_ts + timedelta(hours=interval_h)):
                        temperatura = round(random.uniform(18.0, 30.0), 2)
                        vlaga       = round(random.uniform(30.0, 80.0), 2)
                        svjetlost   = round(random.uniform(100.0, 1000.0), 1)

                        cur.execute("""
                            INSERT INTO mjerenje_izvor
                              (biljka_id, izvor, temperatura, vlaga, svjetlost, datum_mjerenja)
                            VALUES (%s, 'senzor', %s, %s, %s, NOW())
                        """, (biljka_id, temperatura, vlaga, svjetlost))
                        logging.info(f"[SensorThread] inserted sensor reading for plant {biljka_id}")

                time.sleep(self.poll_interval)
        finally:
            cur.close()
            conn.close()

    def stop(self):
        self._running = False

# preserve standalone entrypoint if needed
def main():
    SensorThread().run()

if __name__ == "__main__":
    main()