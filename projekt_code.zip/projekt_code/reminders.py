from PyQt5.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel, QLineEdit,
    QComboBox, QCheckBox, QPushButton, QTableWidget,
    QTableWidgetItem, QMessageBox, QDateTimeEdit, QSpinBox, QDialog
)
from PyQt5.QtCore import Qt, pyqtSignal
from datetime import datetime, timedelta
from dateutil.relativedelta import relativedelta
from db import get_db_connection    
from utils import fetch_plants   

class RemindersWidget(QWidget):
    def __init__(self, user_id):
        super().__init__()
        self.user_id = user_id
        self.initUI()

    def initUI(self):
        self.setWindowTitle('Podsjetnici')
        main_layout = QVBoxLayout(self)

       # --- Filter / Refresh bar ---------------------------------------
        filter_layout = QHBoxLayout()
        filter_layout.addWidget(QLabel("Pretraži:", self))
        self.search_input = QLineEdit(self)
        self.search_input.setPlaceholderText("Naziv podsjetnika ili biljke…")
        filter_layout.addWidget(self.search_input)

        # → Sort combo
        filter_layout.addWidget(QLabel("Sortiraj po:", self))
        self.sort_combo = QComboBox(self)
        self.sort_combo.addItems([
            "Datum ↑", "Datum ↓",
            "Biljka A-Z", "Biljka Z-A",
            "Podsjetnik A-Z", "Podsjetnik Z-A",
            "Ponavljajuće ↑", "Ponavljajuće ↓",
            "Interval ↑", "Interval ↓",
            "Jedinica A-Z",   "Jedinica Z-A"
        ])
        filter_layout.addWidget(self.sort_combo)

        # → Next 7 days checkbox
        self.upcoming_chk = QCheckBox("Samo idući 7 dana", self)
        filter_layout.addWidget(self.upcoming_chk)

        # → Show old reminders
        self.show_old_chk = QCheckBox("Prikaži stare podsjetnike", self)
        filter_layout.addWidget(self.show_old_chk)

        filter_layout.addStretch()
        self.refresh_btn = QPushButton("Osvježi", self)
        filter_layout.addWidget(self.refresh_btn)
        main_layout.addLayout(filter_layout)

        # --- Table ------------------------------------------------------
        self.table = QTableWidget(self)
        self.table.setColumnCount(7)
        self.table.setHorizontalHeaderLabels([
            "Datum i vrijeme", "Biljka", "Podsjetnik",
            "Ponavljajuće", "Interval", "Jedinica", "Akcije"
        ])
        self.table.horizontalHeader().setStretchLastSection(True)
        self.table.setAlternatingRowColors(True)
        self.table.setSortingEnabled(True)
        main_layout.addWidget(self.table)

        # --- Connections & initial load --------------------------------
        self.search_input.textChanged.connect(self.apply_filter)
        self.sort_combo.currentIndexChanged.connect(self.apply_sort)
        self.upcoming_chk.stateChanged.connect(self.apply_filter)
        self.show_old_chk.stateChanged.connect(self.apply_filter)
        self.refresh_btn.clicked.connect(self.refresh_reminders)
        self.refresh_reminders()

    def refresh_reminders(self):
        self.items = self.fetch_reminders()
        self.apply_filter()  

    def apply_filter(self):
        term = self.search_input.text().lower()
        now = datetime.now()
        week_later = now + timedelta(days=7)
        show_old = self.show_old_chk.isChecked()

        visible = []
        for rem in self.items:
            # hide non-repetitive past unless “show old” is checked
            if not rem['ponavljajuci'] and rem['datum'] < now and not show_old:
                continue
            # text match
            if term not in rem['biljka'].lower() and term not in rem['naziv'].lower():
                continue
            # upcoming 7 days filter
            if self.upcoming_chk.isChecked():
                if not (now <= rem['datum'] <= week_later):
                    continue
            visible.append(rem)

        self.table.setRowCount(len(visible))
        for row, rem in enumerate(visible):
            items = [
                QTableWidgetItem(rem['datum'].strftime('%Y-%m-%d %H:%M')),
                QTableWidgetItem(rem['biljka']),
                QTableWidgetItem(rem['naziv']),
                QTableWidgetItem("Da" if rem['ponavljajuci'] else "Ne"),
                QTableWidgetItem(str(rem['interval'])),
                QTableWidgetItem(rem['jedinica'])
            ]

            for col, it in enumerate(items):
                self.table.setItem(row, col, it)

            action_w = QWidget()
            hl = QHBoxLayout(action_w)
            hl.setContentsMargins(0,0,0,0)
            btn_edit = QPushButton("Uredi")
            btn_del  = QPushButton("Obriši")
            hl.addWidget(btn_edit)
            hl.addWidget(btn_del)
            self.table.setCellWidget(row, 6, action_w)

            btn_edit.clicked.connect(lambda _, r=rem: self.open_edit_dialog(r))
            btn_del.clicked.connect(lambda _, r=rem: self.delete_reminder(r))
        self.apply_sort()

    def open_edit_dialog(self, rem):
        dlg = EditReminderDialog(self.user_id, rem, self)
        dlg.reminder_updated.connect(self.refresh_reminders)
        dlg.exec_()

    def delete_reminder(self, rem):
        ok = QMessageBox.question(
            self, "Potvrda",
            f"Jeste li sigurni da želite obrisati '{rem['naziv']}'?"
        ) == QMessageBox.Yes
        if not ok:
            return
        conn = get_db_connection(); cur = conn.cursor()
        cur.execute("DELETE FROM podsjetnik WHERE id = %s", (rem['id'],))
        conn.commit(); cur.close(); conn.close()
        self.refresh_reminders()

    def apply_sort(self):
        idx = self.sort_combo.currentIndex()
        if   idx == 0:  self.table.sortItems(0, Qt.AscendingOrder)
        elif idx == 1:  self.table.sortItems(0, Qt.DescendingOrder)
        elif idx == 2:  self.table.sortItems(1, Qt.AscendingOrder)
        elif idx == 3:  self.table.sortItems(1, Qt.DescendingOrder)
        elif idx == 4:  self.table.sortItems(2, Qt.AscendingOrder)
        elif idx == 5:  self.table.sortItems(2, Qt.DescendingOrder)
        elif idx == 6:  self.table.sortItems(3, Qt.AscendingOrder)  # ponavljajuće
        elif idx == 7:  self.table.sortItems(3, Qt.DescendingOrder)
        elif idx == 8:  self.table.sortItems(4, Qt.AscendingOrder)  # interval
        elif idx == 9:  self.table.sortItems(4, Qt.DescendingOrder)
        elif idx == 10: self.table.sortItems(5, Qt.AscendingOrder)  # jedinica
        elif idx == 11: self.table.sortItems(5, Qt.DescendingOrder)

    def fetch_reminders(self):
        reminders = []
        conn = None
        try:
            conn = get_db_connection()
            cur = conn.cursor()
            cur.execute("""
                SELECT
                  r.id,
                  r.naziv,
                  r.datum_podsjetnika AS datum,
                  b.naziv           AS biljka,
                  r.ponavljajuci,
                  r.ponavljanje_interval,
                  r.ponavljanje_jedinica
                FROM podsjetnik r
                JOIN biljka b  ON r.biljka_id = b.id
                JOIN biljka_korisnik bk ON b.id = bk.biljka_id
                WHERE bk.korisnik_id = %s
                ORDER BY r.datum_podsjetnika ASC
            """, (self.user_id,))
            rows = cur.fetchall()
            now = datetime.now()

            for rid, name, datum, plant, rep, interval, unit in rows:
                rem = {
                    'id': rid,
                    'naziv': name,
                    'datum': datum,
                    'biljka': plant,
                    'ponavljajuci': rep,
                    'interval': interval or 0,
                    'jedinica': unit or ""
                }

                # if repetitive & past, roll forward
                if rep and datum < now:
                    new_dt = datum
                    while new_dt < now:
                        if unit == "Sat":
                            new_dt += relativedelta(hours=interval)
                        elif unit == "Dan":
                            new_dt += relativedelta(days=interval)
                        elif unit == "Tjedan":
                            new_dt += relativedelta(weeks=interval)
                        elif unit == "Mjesec":
                            new_dt += relativedelta(months=interval)
                        elif unit == "Godina":
                            new_dt += relativedelta(years=interval)
                    cur.execute(
                        "UPDATE podsjetnik SET datum_podsjetnika = %s WHERE id = %s",
                        (new_dt, rid)
                    )
                    conn.commit()
                    rem['datum'] = new_dt

                reminders.append(rem)

            cur.close()
        except Exception as e:
            QMessageBox.critical(self, 'Error', str(e))
        finally:
            if conn:
                conn.close()
        return reminders


class AddReminderWindow(QWidget):
    reminder_added = pyqtSignal()

    def __init__(self, user_id):
        super().__init__()
        self.user_id = user_id
        self.initUI()

    def initUI(self):
        self.setWindowTitle('Dodaj Podsjetnik')
        self.setGeometry(200, 200, 300, 200)

        layout = QVBoxLayout(self)

        # Plant selector
        layout.addWidget(QLabel('Biljka:', self))
        self.plant_combo = QComboBox(self)
        for p in fetch_plants(self.user_id):
            self.plant_combo.addItem(p['naziv'], p['id'])
        layout.addWidget(self.plant_combo)

        # Reminder name
        layout.addWidget(QLabel('Naziv podsjetnika:', self))
        self.name_input = QLineEdit(self)
        layout.addWidget(self.name_input)

        # Date/time picker
        layout.addWidget(QLabel('Datum i vrijeme:', self))
        self.dt_edit = QDateTimeEdit(datetime.now(), self)
        self.dt_edit.setDisplayFormat('yyyy-MM-dd HH:mm')
        self.dt_edit.setCalendarPopup(True)
        layout.addWidget(self.dt_edit)

        # ← new: repetition controls
        self.repeat_chk = QCheckBox("Ponavljajući", self)
        self.repeat_chk.toggled.connect(self.toggle_repeat_fields)
        layout.addWidget(self.repeat_chk)

        self.interval_spin = QSpinBox(self)
        self.interval_spin.setRange(1, 365)
        self.interval_spin.setValue(1)
        self.interval_spin.setEnabled(False)
        layout.addWidget(self.interval_spin)

        self.unit_combo = QComboBox(self)
        self.unit_combo.addItems(["Sat", "Dan", "Tjedan", "Mjesec", "Godina"])
        self.unit_combo.setEnabled(False)
        layout.addWidget(self.unit_combo)

        btn = QPushButton('Dodaj', self)
        btn.clicked.connect(self.add_reminder)
        layout.addWidget(btn)

    # ← new helper
    def toggle_repeat_fields(self, checked):
        self.interval_spin.setEnabled(checked)
        self.unit_combo.setEnabled(checked)
    
    def add_reminder(self):
        plant_id = self.plant_combo.currentData()
        name     = self.name_input.text().strip()
        dt       = self.dt_edit.dateTime().toPyDateTime()
        ponavljajuci = self.repeat_chk.isChecked()
        interval     = self.interval_spin.value() if ponavljajuci else None
        jedinica     = self.unit_combo.currentText() if ponavljajuci else None

        if not name:
            QMessageBox.warning(self, 'Error', 'Unesite naziv podsjetnika')
            return

        try:
            conn = get_db_connection()
            cur  = conn.cursor()
            cur.execute("""
                INSERT INTO podsjetnik (
                    biljka_id, naziv, datum_podsjetnika,
                    ponavljajuci, ponavljanje_interval, ponavljanje_jedinica
                ) VALUES (%s,%s,%s,%s,%s,%s)
            """, (plant_id, name, dt, ponavljajuci, interval, jedinica))
            conn.commit()
            cur.close()
            QMessageBox.information(self, 'Success', 'Podsjetnik dodan')
            self.reminder_added.emit()
            self.close()
        except Exception as e:
            QMessageBox.critical(self, 'Error', str(e))
        finally:
            if conn: conn.close()

class EditReminderDialog(QDialog):
    reminder_updated = pyqtSignal()

    def __init__(self, user_id, rem, parent=None):
        super().__init__(parent)
        self.user_id = user_id
        self.rem = rem
        self.initUI()

    def initUI(self):
        self.setWindowTitle('Uredi podsjetnik')
        layout = QVBoxLayout(self)

        # Biljka (neuredivo u editu)
        layout.addWidget(QLabel(f"Biljka: {self.rem['biljka']}", self))

        # Naziv
        layout.addWidget(QLabel('Naziv podsjetnika:', self))
        self.name_input = QLineEdit(self)
        self.name_input.setText(self.rem['naziv'])
        layout.addWidget(self.name_input)

        # Datum i vrijeme
        layout.addWidget(QLabel('Datum i vrijeme:', self))
        self.dt_edit = QDateTimeEdit(self.rem['datum'], self)
        self.dt_edit.setDisplayFormat('yyyy-MM-dd HH:mm')
        self.dt_edit.setCalendarPopup(True)
        layout.addWidget(self.dt_edit)

        # Ponavljajući
        self.repeat_chk = QCheckBox("Ponavljajući", self)
        self.repeat_chk.setChecked(self.rem['ponavljajuci'])
        self.repeat_chk.toggled.connect(self.toggle_repeat_fields)
        layout.addWidget(self.repeat_chk)

        self.interval_spin = QSpinBox(self)
        self.interval_spin.setRange(1, 365)
        self.interval_spin.setValue(self.rem['interval'])
        self.interval_spin.setEnabled(self.rem['ponavljajuci'])
        layout.addWidget(self.interval_spin)

        self.unit_combo = QComboBox(self)
        self.unit_combo.addItems(["Sat", "Dan", "Tjedan", "Mjesec", "Godina"])
        if self.rem['jedinica']:
            self.unit_combo.setCurrentText(self.rem['jedinica'])
        self.unit_combo.setEnabled(self.rem['ponavljajuci'])
        layout.addWidget(self.unit_combo)

        # Gumbi
        hb = QHBoxLayout()
        btn_save = QPushButton("Spremi")
        btn_cancel = QPushButton("Odustani")
        btn_save.clicked.connect(self.save_changes)
        btn_cancel.clicked.connect(self.reject)
        hb.addWidget(btn_save)
        hb.addWidget(btn_cancel)
        layout.addLayout(hb)

    def toggle_repeat_fields(self, checked):
        self.interval_spin.setEnabled(checked)
        self.unit_combo.setEnabled(checked)

    def save_changes(self):
        name = self.name_input.text().strip()
        dt   = self.dt_edit.dateTime().toPyDateTime()
        rep  = self.repeat_chk.isChecked()
        interval = self.interval_spin.value() if rep else None
        unit     = self.unit_combo.currentText() if rep else None

        if not name:
            QMessageBox.warning(self, 'Greška', 'Naziv ne smije biti prazan')
            return

        try:
            conn = get_db_connection()
            cur  = conn.cursor()
            cur.execute("""
                UPDATE podsjetnik
                   SET naziv = %s,
                       datum_podsjetnika = %s,
                       ponavljajuci = %s,
                       ponavljanje_interval = %s,
                       ponavljanje_jedinica = %s
                 WHERE id = %s
            """, (name, dt, rep, interval, unit, self.rem['id']))
            conn.commit()
            cur.close()
            QMessageBox.information(self, 'OK', 'Podsjetnik ažuriran')
            self.reminder_updated.emit()
            self.accept()
        except Exception as e:
            QMessageBox.critical(self, 'Error', str(e))
        finally:
            if conn: conn.close()