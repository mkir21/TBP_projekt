from PyQt5.QtWidgets import QWidget, QVBoxLayout, QLabel, QScrollArea, QGridLayout, QMessageBox,\
    QPushButton, QHBoxLayout, QLineEdit, QTextEdit, QDialog, QStyle, QInputDialog
from PyQt5.QtCore import Qt, pyqtSignal, QSize 
from PyQt5.QtGui import QPixmap
from db import get_db_connection
from utils import load_plant_pixmap, ClickableLabel  

class PlantsWidget(QWidget):
    def __init__(self, user_id, stacked_widget):
        super().__init__()
        self.user_id = user_id
        self.stacked_widget = stacked_widget
        self.initUI()

    def initUI(self):
        self.layout = QVBoxLayout()
        self.label = QLabel('Biljke:', self)
        self.label.setAlignment(Qt.AlignCenter)
        self.label.setStyleSheet("font-size: 26px; margin-bottom: 15px;")

        self.scroll_area = QScrollArea(self)
        self.scroll_area.setWidgetResizable(True)

        self.plants_container = QWidget()
        self.plants_layout = QGridLayout(self.plants_container)
        self.plants_layout.setSpacing(20)

        self.scroll_area.setWidget(self.plants_container)

        self.layout.addWidget(self.label)
        self.layout.addWidget(self.scroll_area)
        self.layout.setContentsMargins(20, 20, 20, 20)
        self.setLayout(self.layout)

        self.refresh_plants()

    def showEvent(self, event):
        self.refresh_plants()
        super().showEvent(event)

    def refresh_plants(self):
        plants = self.fetch_plants()
        for i in reversed(range(self.plants_layout.count())): 
            widgetToRemove = self.plants_layout.itemAt(i).widget()
            self.plants_layout.removeWidget(widgetToRemove)
            widgetToRemove.setParent(None)

        for index, plant in enumerate(plants):
            row = index // 2
            col = index % 2

            plant_widget = QWidget(self)
            plant_layout = QVBoxLayout(plant_widget)

            plant_image = QLabel(self)
            image_path = 'path_to_image.png'  # Replace with the actual path to the plant image
            if not QPixmap(image_path).isNull():
                pixmap = QPixmap(image_path)
            else:
                pixmap = QPixmap('/home/marko/Documents/TBP_projekt/logo.png')  # Replace with the actual path to the placeholder image
            pixmap = load_plant_pixmap(plant['id'])
            plant_image.setPixmap(pixmap.scaled(100, 100, Qt.KeepAspectRatio, Qt.SmoothTransformation))
            plant_image.setAlignment(Qt.AlignCenter)

            plant_label = ClickableLabel(plant_widget)
            plant_label.setText(plant['naziv'])
            plant_label.setAlignment(Qt.AlignCenter)
            plant_label.setStyleSheet("""
                QLabel {
                    font-size: 22px;
                    padding: 10px;
                }
                QLabel:hover {
                    color: green;
                    text-decoration: underline;
                    cursor: pointer;
                }
            """)
            plant_label.clicked.connect(lambda p=plant: self.open_plant_detail(p))

            plant_layout.addWidget(plant_image)
            plant_layout.addWidget(plant_label)
            plant_widget.setLayout(plant_layout)

            self.plants_layout.addWidget(plant_widget, row, col)

    def fetch_plants(self):
        plants = []
        conn = None
        try:
            conn = get_db_connection()
            cur = conn.cursor()
            cur.execute("""
                SELECT p.id, p.naziv, p.opis, p.vrsta
                FROM biljka p
                JOIN biljka_korisnik bk ON p.id = bk.biljka_id
                WHERE bk.korisnik_id = %s
                AND p.aktivna = TRUE
            """, (self.user_id,))
            rows = cur.fetchall()
            plants = [
                {'id': row[0], 'naziv': row[1], 'opis': row[2], 'vrsta': row[3]}
                for row in rows
            ]
            cur.close()
        except Exception as e:
            QMessageBox.critical(self, 'Error', str(e))
        finally:
            if conn: conn.close()
        return plants

    def open_plant_detail(self, plant):
        plant_detail_widget = PlantDetailWidget(plant, self)
        self.stacked_widget.addWidget(plant_detail_widget)
        self.stacked_widget.setCurrentWidget(plant_detail_widget)

class PlantDetailWidget(QWidget):
    def __init__(self, plant, parent_widget):
        super().__init__(parent_widget)
        self.plant = plant
        self.parent_widget = parent_widget

        self.main_layout = QVBoxLayout(self)
        self.main_layout.setContentsMargins(20, 20, 20, 20)
        self.main_layout.setSpacing(15)

        self.initUI()

    def clear_layout(self, layout):
        """Recursively delete all widgets and sublayouts from a given layout."""
        while layout.count():
            item = layout.takeAt(0)
            if item.widget():
                item.widget().deleteLater()
            elif item.layout():
                self.clear_layout(item.layout())

    def initUI(self):
        self.clear_layout(self.main_layout)

        self.setWindowTitle(self.plant['naziv'])
        v = self.main_layout

        # — Header with Back button & Title —
        hb = QHBoxLayout()
        back_btn = QPushButton("Nazad", self)
        back_btn.setIcon(self.style().standardIcon(QStyle.SP_ArrowBack))
        back_btn.setIconSize(QSize(20,20))
        back_btn.setCursor(Qt.PointingHandCursor)
        back_btn.setMinimumHeight(40)
        back_btn.setStyleSheet("""
            QPushButton { font-size:16px; padding:6px 12px; }
        """)
        back_btn.clicked.connect(self.go_back)
        hb.addWidget(back_btn, alignment=Qt.AlignLeft)

        title = QLabel(self.plant['naziv'], self)
        title.setStyleSheet("font-size:24px;font-weight:bold;")
        hb.addWidget(title, alignment=Qt.AlignVCenter)
        hb.addStretch()
        v.addLayout(hb)

        # — Content: Image | Details —
        content = QHBoxLayout()
        content.setSpacing(40)
        content.setAlignment(Qt.AlignTop)

        # Left: Picture, make it bigger
        pic_label = QLabel(self)
        pix = load_plant_pixmap(self.plant['id'])
        if pix.isNull():
            pix = QPixmap('/home/marko/Documents/TBP_projekt/logo.png')
        # scale to a larger width:
        pix = pix.scaledToWidth(350, Qt.SmoothTransformation)
        pic_label.setPixmap(pix)
        pic_label.setAlignment(Qt.AlignTop)
        content.addWidget(pic_label, stretch=1)

        # Right: Details with larger font
        details = QVBoxLayout()
        details.setSpacing(15)

        lbl_name = QLabel(f"<b>Naziv:</b> {self.plant['naziv']}", self)
        lbl_name.setWordWrap(True)
        lbl_name.setStyleSheet("font-size:20px;")
        details.addWidget(lbl_name)

        lbl_desc = QLabel(f"<b>Opis:</b> {self.plant['opis']}", self)
        lbl_desc.setWordWrap(True)
        lbl_desc.setStyleSheet("font-size:18px;")
        details.addWidget(lbl_desc)

        lbl_sp = QLabel(f"<b>Vrsta:</b> {self.plant.get('vrsta','–')}", self)
        lbl_sp.setWordWrap(True)
        lbl_sp.setStyleSheet("font-size:18px;")
        details.addWidget(lbl_sp)

        details.addStretch()
        content.addLayout(details, stretch=2)

        v.addLayout(content)

        # — Footer buttons —
        ft = QHBoxLayout()
        ft.addStretch()
        btn_s = QPushButton("Dodijeli brigu", self)
        btn_s.clicked.connect(self.share_plant)
        btn_e = QPushButton("Uredi biljku", self)
        btn_e.clicked.connect(self.edit_plant)
        btn_d = QPushButton("Obriši biljku", self)
        btn_d.clicked.connect(self.delete_plant)
        ft.addWidget(btn_s)
        ft.addWidget(btn_e)
        ft.addWidget(btn_d)
        v.addLayout(ft)

    def go_back(self):
        self.parent_widget.stacked_widget.setCurrentWidget(self.parent_widget)

    # stub methods—implement your edit/delete logic
    def edit_plant(self):
        dlg = EditPlantDialog(self.plant, self)
        dlg.plant_updated.connect(self._on_updated)
        dlg.exec_()

    def delete_plant(self):
        if QMessageBox.question(self, "Potvrda",
               "Jeste li sigurni da želite obrisati ovu biljku?") != QMessageBox.Yes:
            return

        conn = get_db_connection()
        cur = conn.cursor()

        # 1) prebroji koliko korisnika veže ovu biljku
        cur.execute("""
            SELECT COUNT(*) 
              FROM biljka_korisnik 
             WHERE biljka_id = %s
        """, (self.plant['id'],))
        user_count = cur.fetchone()[0]

        if user_count > 1:
            # ako ima više korisnika, obriši samo vezu za ovog korisnika
            cur.execute("""
                DELETE 
                  FROM biljka_korisnik
                 WHERE korisnik_id = %s
                   AND biljka_id = %s
            """, (self.parent_widget.user_id, self.plant['id']))
        else:
            # inače soft‐delete biljke
            cur.execute("""
                UPDATE biljka
                   SET aktivna = FALSE,
                       datum_deaktivacije = NOW()
                 WHERE id = %s
            """, (self.plant['id'],))

        conn.commit()
        cur.close()
        conn.close()

        # osvježi i vrati se na popis
        self.parent_widget.refresh_plants()
        self.parent_widget.stacked_widget.setCurrentWidget(self.parent_widget)
    
    def share_plant(self):
        # 1) upit korisnika
        email, ok = QInputDialog.getText(self, "Podijeli biljku",
                                         "Unesite e-mail korisnika s kojim dijelite:")
        if not ok or not email.strip():
            return

        conn = get_db_connection()
        cur = conn.cursor()
        try:
            # 2) dohvati ID tog korisnika
            cur.execute("SELECT id FROM korisnik WHERE email = %s", (email.strip(),))
            row = cur.fetchone()
            if not row:
                QMessageBox.warning(self, "Greška", "Korisnik s tim e-mailom ne postoji.")
            else:
                target_id = row[0]
                # 3) ubaci u biljka_korisnik
                cur.execute("""
                    INSERT INTO biljka_korisnik (korisnik_id, biljka_id, uloga)
                    VALUES (%s, %s, 'viewer')
                """, (target_id, self.plant['id']))
                conn.commit()
                QMessageBox.information(self, "OK", f"Biljka podijeljena s {email}.")
        except Exception as e:
            QMessageBox.critical(self, "Greška", str(e))
        finally:
            cur.close()
            conn.close()
    
    def _on_updated(self, dlg):
        # pull updated fields from the dialog
        self.plant['naziv'] = dlg.name_input.text().strip()
        self.plant['opis'] = dlg.desc_input.toPlainText().strip()
        if hasattr(dlg, 'species_input'):
            self.plant['vrsta'] = dlg.species_input.text().strip()
        self.initUI()
        self.parent_widget.refresh_plants()

class AddPlantWindow(QWidget):
    plant_added = pyqtSignal()

    def __init__(self, user_id):
        super().__init__()
        self.user_id = user_id
        self.initUI()

    def initUI(self):
        self.setWindowTitle('Dodaj Biljku')
        self.setGeometry(100, 100, 400, 300)  # Set the window size

        self.name_label = QLabel('Naziv:', self)
        self.name_input = QLineEdit(self)

        self.description_label = QLabel('Opis:', self)
        self.description_input = QLineEdit(self)

        self.species_label = QLabel('Vrsta:', self)
        self.species_input = QLineEdit(self)

        self.add_button = QPushButton('Dodaj', self)
        self.add_button.clicked.connect(self.add_plant)

        layout = QVBoxLayout()
        layout.addWidget(self.name_label)
        layout.addWidget(self.name_input)
        layout.addWidget(self.description_label)
        layout.addWidget(self.description_input)
        layout.addWidget(self.species_label)
        layout.addWidget(self.species_input)
        layout.addWidget(self.add_button)

        self.setLayout(layout)

    def add_plant(self):
        name = self.name_input.text()
        description = self.description_input.text()
        species = self.species_input.text()

        if not name or not description or not species:
            QMessageBox.warning(self, 'Error', 'All fields are required')
            return

        conn = None
        try:
            conn = get_db_connection()
            cur = conn.cursor()
            cur.execute("""
                INSERT INTO biljka (naziv, opis, vrsta)
                VALUES (%s, %s, %s) RETURNING id
            """, (name, description, species))
            plant_id = cur.fetchone()[0]

            cur.execute("""
                INSERT INTO biljka_korisnik (korisnik_id, biljka_id, uloga)
                VALUES (%s, %s, 'owner')
            """, (self.user_id, plant_id))

            conn.commit()
            cur.close()
            QMessageBox.information(self, 'Success', 'Plant added successfully!')
            self.plant_added.emit()
            self.close()
        except Exception as e:
            QMessageBox.critical(self, 'Error', str(e))
        finally:
            if conn:
                conn.close()

class EditPlantDialog(QDialog):
    plant_updated = pyqtSignal(object)

    def __init__(self, plant, parent=None):
        super().__init__(parent)
        self.plant = plant
        self.initUI()

    def initUI(self):
        self.setWindowTitle("Uredi biljku")
        v = QVBoxLayout(self)

        v.addWidget(QLabel("Naziv:", self))
        self.name_input = QLineEdit(self)
        self.name_input.setText(self.plant['naziv'])
        v.addWidget(self.name_input)

        v.addWidget(QLabel("Opis:", self))
        self.desc_input = QTextEdit(self)
        self.desc_input.setText(self.plant['opis'])
        v.addWidget(self.desc_input)

        v.addWidget(QLabel("Vrsta:", self))
        self.species_input = QLineEdit(self)
        self.species_input.setText(self.plant.get('vrsta',''))
        v.addWidget(self.species_input)

        hb = QHBoxLayout()
        btn_save   = QPushButton("Spremi", self)
        btn_cancel = QPushButton("Odustani", self)
        hb.addWidget(btn_save); hb.addWidget(btn_cancel)
        v.addLayout(hb)

        btn_save.clicked.connect(self._save)
        btn_cancel.clicked.connect(self.reject)

    def _save(self):
        name = self.name_input.text().strip()
        if not name:
            QMessageBox.warning(self, "Greška", "Naziv ne smije biti prazan")
            return
        desc    = self.desc_input.toPlainText().strip()
        species = self.species_input.text().strip()
        try:
            conn = get_db_connection(); cur = conn.cursor()
            cur.execute("""
              UPDATE biljka
                 SET naziv=%s, opis=%s, vrsta=%s
               WHERE id=%s
            """, (name, desc, species, self.plant['id']))
            conn.commit(); cur.close(); conn.close()
            QMessageBox.information(self, "OK", "Biljka uređena")
            self.plant_updated.emit(self)
            self.accept()
        except Exception as e:
            QMessageBox.critical(self, "Greška", str(e))
            if conn: conn.close()