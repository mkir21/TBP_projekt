from PyQt5.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLineEdit,  
    QComboBox, QPushButton, QTableWidget, QSpinBox,
    QTableWidgetItem, QMessageBox, QDoubleSpinBox, QLabel
)
from PyQt5.QtCore import Qt, pyqtSignal, QTimer
from datetime import datetime
from db import get_db_connection
from utils import fetch_plants

class MeasurementsWidget(QWidget):
    def __init__(self, user_id, mainwindow):
        super().__init__()
        self.user_id    = user_id
        self.mainwindow = mainwindow
        self.initUI()

    def initUI(self):
        self.setWindowTitle('Mjerenja')
        layout = QVBoxLayout(self)

        # --- controls ---
        ctrl = QHBoxLayout()
        self.search    = QLineEdit(self)
        self.search.setPlaceholderText("Traži (biljku)…")
        self.search.textChanged.connect(self.apply_filter)
        ctrl.addWidget(self.search)

        self.sort_combo = QComboBox(self)
        self.sort_combo.addItems([
           "Datum ↑",    "Datum ↓",
           "Temp ↑",     "Temp ↓",
           "Biljka A-Z", "Biljka Z-A",
           "Vlaga ↑",    "Vlaga ↓",
           "Svjetlost ↑","Svjetlost ↓"
       ])
        self.sort_combo.currentIndexChanged.connect(self.apply_sort)
        ctrl.addWidget(self.sort_combo)

        btn = QPushButton("Dodaj očitanje", self)
        btn.clicked.connect(self.mainwindow.open_add_measurement_window)
        ctrl.addWidget(btn)
        layout.addLayout(ctrl)

        # --- table ---
        self.table = QTableWidget(self)
        self.table.setColumnCount(6)
        self.table.setHorizontalHeaderLabels([
           "Biljka", "Izvor", "Temperatura", "Vlaga", "Svjetlost", "Datum"
        ])
        self.table.horizontalHeader().setStretchLastSection(True)
        self.table.setEditTriggers(QTableWidget.NoEditTriggers)
        layout.addWidget(self.table)

        self.refresh_measurements()

        self._refresh_timer = QTimer(self)
        self._refresh_timer.setInterval(60_000)          # 60 000 ms = 60 s
        self._refresh_timer.timeout.connect(self.refresh_measurements)
        self._refresh_timer.start()

    def refresh_measurements(self):
        self.items = self.fetch_measurements()
        self.apply_filter()

    def fetch_measurements(self):
        measurements = []
        conn = get_db_connection()
        cur  = conn.cursor()
        cur.execute("""
            SELECT m.biljka_id, p.naziv, m.izvor, m.temperatura, m.vlaga, m.svjetlost, m.datum_mjerenja
              FROM mjerenje_izvor m
              JOIN biljka p ON p.id = m.biljka_id
             WHERE m.biljka_id IN (
                 SELECT biljka_id FROM biljka_korisnik WHERE korisnik_id = %s
             )
             ORDER BY m.datum_mjerenja ASC
        """, (self.user_id,))
        for pid, plant_name, izv, tmp, vlg, svjt, dt in cur.fetchall():
            measurements.append({
                'biljka':   plant_name,
                'izvor':    izv,
                'temp':     tmp,
                'vlaga':    vlg,
                'svjetlost':svjt,
                'datum':    dt
            })
        cur.close()
        conn.close()
        return measurements

    def apply_filter(self):
        term = self.search.text().lower()
        # search only by plant name
        rows = [m for m in self.items if term in m['biljka'].lower()]
        self.table.setRowCount(len(rows))
        for i, m in enumerate(rows):
            self.table.setItem(i,0, QTableWidgetItem(m['biljka']))
            self.table.setItem(i,1, QTableWidgetItem(m['izvor']))
            self.table.setItem(i,2, QTableWidgetItem(f"{m['temp']}"))
            self.table.setItem(i,3, QTableWidgetItem(f"{m['vlaga']}"))
            self.table.setItem(i,4, QTableWidgetItem(f"{m['svjetlost']}"))
            self.table.setItem(i,5, QTableWidgetItem(m['datum'].strftime('%Y-%m-%d %H:%M')))

    def apply_sort(self):
        idx = self.sort_combo.currentIndex()
        # columns: 0=Biljka,1=Izvor,2=Temp,3=Vlaga,4=Svjetlost,5=Datum
        if   idx == 0:  self.table.sortItems(5, Qt.AscendingOrder)
        elif idx == 1:  self.table.sortItems(5, Qt.DescendingOrder)
        elif idx == 2:  self.table.sortItems(2, Qt.AscendingOrder)
        elif idx == 3:  self.table.sortItems(2, Qt.DescendingOrder)
        elif idx == 4:  self.table.sortItems(0, Qt.AscendingOrder)
        elif idx == 5:  self.table.sortItems(0, Qt.DescendingOrder)
        elif idx == 6:  self.table.sortItems(3, Qt.AscendingOrder)
        elif idx == 7:  self.table.sortItems(3, Qt.DescendingOrder)
        elif idx == 8:  self.table.sortItems(4, Qt.AscendingOrder)
        elif idx == 9:  self.table.sortItems(4, Qt.DescendingOrder)


class AddMeasurementWindow(QWidget):
    measurement_added = pyqtSignal()

    def __init__(self, user_id):
        super().__init__()
        self.user_id = user_id
        self.timer   = None
        self.initUI()

    def initUI(self):
        self.setWindowTitle("Dodaj očitanje")
        layout = QVBoxLayout(self)

        layout.addWidget(QLabel("Izvor:", self))
        self.source_combo = QComboBox(self)
        self.source_combo.addItems(["Manual","Sensor"])
        self.source_combo.currentTextChanged.connect(self.toggle_fields)
        layout.addWidget(self.source_combo)

        layout.addWidget(QLabel("Biljka:", self))
        self.plant_combo = QComboBox(self)
        for p in fetch_plants(self.user_id):
            self.plant_combo.addItem(p['naziv'], p['id'])
        layout.addWidget(self.plant_combo)

        # manual fields
        self.temp_spin     = QDoubleSpinBox(self)
        self.temp_spin.setRange(-50,100);    self.temp_spin.setSuffix(" °C")
        layout.addWidget(QLabel("Temperatura:", self)); layout.addWidget(self.temp_spin)

        self.humidity_spin = QDoubleSpinBox(self)
        self.humidity_spin.setRange(0,100);   self.humidity_spin.setSuffix(" %")
        layout.addWidget(QLabel("Vlaga:", self));      layout.addWidget(self.humidity_spin)

        self.light_spin    = QDoubleSpinBox(self)
        self.light_spin.setRange(0,200000);   self.light_spin.setSuffix(" lx")
        layout.addWidget(QLabel("Svjetlost:", self));  layout.addWidget(self.light_spin)

        # sensor interval
        layout.addWidget(QLabel("Interval mjerenja (h):", self))
        self.interval_spin = QDoubleSpinBox(self)
        self.interval_spin.setRange(0.01, 24.0)      # from 0.01 h (≈36 s) up to 24 h
        self.interval_spin.setDecimals(2)
        self.interval_spin.setSingleStep(0.1)        # step by 0.1 h (6 min)
        self.interval_spin.setSuffix(" h")
        layout.addWidget(self.interval_spin)

        self.action_btn = QPushButton("Spremi", self)
        self.action_btn.clicked.connect(self.on_action)
        layout.addWidget(self.action_btn)

        self.del_btn = QPushButton("Obriši interval", self)
        self.del_btn.clicked.connect(self.on_delete)
        layout.addWidget(self.del_btn)

        # kad se promijeni biljka, učitaj interval
        self.plant_combo.currentIndexChanged.connect(self.load_interval)

        # inicijalno postavi UI
        self.toggle_fields(self.source_combo.currentText())
        self.load_interval()


    def toggle_fields(self, text):
        manual = (text == "Manual")
        for w in (self.temp_spin, self.humidity_spin, self.light_spin):
            w.setVisible(manual)
        self.interval_spin.setVisible(not manual)
        self.action_btn.setText("Spremi" if manual else "Spremi interval")
        # prikaz gumba za brisanje samo u sensor modu
        self.del_btn.setVisible(not manual and hasattr(self, 'has_interval') and self.has_interval)

    def load_interval(self):
        """Učitava postojeći interval iz baze i skriva/ prikazuje gumb za brisanje."""
        pid = self.plant_combo.currentData()
        conn = get_db_connection()
        try:
            with conn.cursor() as cur:
                cur.execute("""
                    SELECT interval_mjerenja
                      FROM postavke_mjerenja
                     WHERE biljka_id = %s
                """, (pid,))
                row = cur.fetchone()
                if row:
                    self.interval_spin.setValue(row[0])
                    self.has_interval = True
                else:
                    # nijedan interval, ostavi default i sakrij delete
                    self.has_interval = False
                self.del_btn.setVisible(not (self.source_combo.currentText()=="Manual") and self.has_interval)
        finally:
            conn.close()

    def on_action(self):
        src = self.source_combo.currentText().lower()
        pid = self.plant_combo.currentData()
        try:
            conn = get_db_connection()
            with conn, conn.cursor() as cur:
                if src == "manual":
                    tmp = self.temp_spin.value()
                    vlg = self.humidity_spin.value()
                    svt = self.light_spin.value()
                    dt  = datetime.now()
                    cur.execute("""
                        INSERT INTO mjerenje_izvor
                            (biljka_id, izvor, korisnik_id, temperatura, vlaga, svjetlost, datum_mjerenja)
                        VALUES (%s, %s, %s, %s, %s, %s, %s)
                    """, (pid, src, self.user_id, tmp, vlg, svt, dt))
                    msg = "Mjerenje spremljeno"
                else:
                    interval = self.interval_spin.value()
                    cur.execute("""
                        INSERT INTO postavke_mjerenja
                            (biljka_id, interval_mjerenja, datum_postavljanja)
                        VALUES (%s, %s, NOW())
                        ON CONFLICT (biljka_id) DO UPDATE
                            SET interval_mjerenja  = EXCLUDED.interval_mjerenja,
                                datum_postavljanja = NOW()
                    """, (pid, interval))
                    msg = "Interval mjerenja spremljen"

            QMessageBox.information(self, "Success", msg)
            self.measurement_added.emit()
            self.close()

        except Exception as e:
            QMessageBox.critical(self, "Error", str(e))
        finally:
            if 'conn' in locals() and conn:
                conn.close()

    def on_delete(self):
        """Briše interval iz postavke za odabranu biljku."""
        pid = self.plant_combo.currentData()
        conn = get_db_connection()
        try:
            with conn, conn.cursor() as cur:
                cur.execute("DELETE FROM postavke_mjerenja WHERE biljka_id = %s", (pid,))
            QMessageBox.information(self, "Uspjeh", "Interval obrisan")
            self.measurement_added.emit()
            self.close()
        except Exception as e:
            QMessageBox.critical(self, "Greška", str(e))
        finally:
            conn.close()