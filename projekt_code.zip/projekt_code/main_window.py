from PyQt5.QtWidgets import QMainWindow, QAction, QMenu, QStackedWidget
from PyQt5.QtCore import QPoint, QTimer
from PyQt5.QtGui import QCursor
from dashboard import DashboardWidget
from plants import PlantsWidget, AddPlantWindow
from reminders import RemindersWidget, AddReminderWindow
from events import EventsWidget, AddEventWindow
from measurements import MeasurementsWidget, AddMeasurementWindow
from galery import GalleryWidget, AddPhotoWindow

class MainWindow(QMainWindow):
    def __init__(self, user_id):
        super().__init__()
        self.user_id = user_id
        self.dashboard = DashboardWidget(user_id)
        self.initUI()

        self.current_menu = None
        self.menu_timer = QTimer(self)
        self.menu_timer.timeout.connect(self.check_menu_hover)

    def initUI(self):
        self.setWindowTitle('Bud-dy')
        self.setGeometry(100, 100, 800, 600)  # Set the window size

        self.toolbar = self.addToolBar('Glavni Toolbar')
        self.toolbar.setMovable(False)
        self.add_toolbar_actions()

        self.stacked_widget = QStackedWidget()
        self.setCentralWidget(self.stacked_widget)

        self.dashboard = DashboardWidget(self.user_id)
        self.plants = PlantsWidget(self.user_id, self.stacked_widget)
        self.reminders = RemindersWidget(self.user_id)
        self.events = EventsWidget(self.user_id, self)   
        self.measurements = MeasurementsWidget(self.user_id, self)        
        self.gallery = GalleryWidget(self.user_id, self.stacked_widget)           

        self.stacked_widget.addWidget(self.dashboard)
        self.stacked_widget.addWidget(self.plants)
        self.stacked_widget.addWidget(self.reminders) 
        self.stacked_widget.addWidget(self.events)                   
        self.stacked_widget.addWidget(self.measurements)       
        self.stacked_widget.addWidget(self.gallery)

    def add_toolbar_actions(self):
        menu_action = QAction('Meni', self)
        menu = QMenu(self)
        submenu_action1 = QAction('Dashboard', self)
        submenu_action2 = QAction('Biljke', self)
        submenu_action3 = QAction('Podsjetnici', self)
        submenu_action4 = QAction('Događaji', self)
        submenu_action5 = QAction('Mjerenja', self)
        submenu_action6 = QAction('Galerija', self)

        menu.addAction(submenu_action1)
        menu.addAction(submenu_action2)
        menu.addAction(submenu_action3)
        menu.addAction(submenu_action4)
        menu.addAction(submenu_action5)
        menu.addAction(submenu_action6)

        submenu_action1.triggered.connect(lambda: self.stacked_widget.setCurrentWidget(self.dashboard))
        submenu_action2.triggered.connect(lambda: self.stacked_widget.setCurrentWidget(self.plants))
        submenu_action3.triggered.connect(lambda: self.stacked_widget.setCurrentWidget(self.reminders))
        submenu_action4.triggered.connect(lambda: self.stacked_widget.setCurrentWidget(self.events)) 
        submenu_action5.triggered.connect(lambda: self.stacked_widget.setCurrentWidget(self.measurements))
        submenu_action6.triggered.connect(lambda: self.stacked_widget.setCurrentWidget(self.gallery))
        

        menu.aboutToHide.connect(self.reset_current_menu)
        menu_action.triggered.connect(lambda: self.show_menu(menu, self.toolbar.geometry().bottomLeft()))
        self.toolbar.addAction(menu_action)

        quick_action = QAction('Dodaj', self)
        quick_menu = QMenu(self)
        subquick_action1 = QAction('Dodaj biljku', self)
        subquick_action2 = QAction('Dodaj podsjetnik', self)
        subquick_action3 = QAction('Dodaj događaj', self)
        subquick_action4 = QAction('Dodaj očitanje', self)
        subquick_action5 = QAction('Dodaj sliku', self)

        quick_menu.addAction(subquick_action1)
        quick_menu.addAction(subquick_action2)
        quick_menu.addAction(subquick_action3)
        quick_menu.addAction(subquick_action4)
        quick_menu.addAction(subquick_action5)

        subquick_action1.triggered.connect(self.open_add_plant_window)
        subquick_action2.triggered.connect(self.open_add_reminder_window)
        subquick_action3.triggered.connect(self.open_add_event_window) 
        subquick_action4.triggered.connect(self.open_add_measurement_window) 
        subquick_action5.triggered.connect(self.open_add_photo_window)

        quick_menu.aboutToHide.connect(self.reset_current_menu)
        quick_action.triggered.connect(lambda: self.show_menu(quick_menu, self.toolbar.geometry().bottomLeft() + QPoint(50, 0)))
        self.toolbar.addAction(quick_action)

        # — Odjava —
        logout_action = QAction('Odjava', self)
        logout_action.triggered.connect(self.logout)
        self.toolbar.addAction(logout_action)
    

    def show_menu(self, menu, position):
        if self.current_menu:
            self.current_menu.hide()
        self.current_menu = menu
        menu.exec_(self.mapToGlobal(position))
        self.menu_timer.start(1000)  # Check every 100 ms

    def reset_current_menu(self):
        self.current_menu = None
        self.menu_timer.stop()

    def check_menu_hover(self):
        if self.current_menu and not self.current_menu.geometry().contains(self.mapFromGlobal(QCursor.pos())):
            self.current_menu.hide()
            self.reset_current_menu()
    
    def logout(self):
        """
        Zatvori glavni prozor i otvori login.
        """
        from login import LoginWindow
        # prvo zatvori glavni prozor
        self.close()
        # pa prikaži login
        self.login_window = LoginWindow()
        self.login_window.show()

    def open_add_plant_window(self):
        self.add_plant_window = AddPlantWindow(self.user_id)
        self.add_plant_window.plant_added.connect(self.plants.refresh_plants)  # Connect the signal
        self.add_plant_window.show()

    def open_add_reminder_window(self):
        self.add_reminder_window = AddReminderWindow(self.user_id)
        # refresh reminders list when a new one is added
        self.add_reminder_window.reminder_added.connect(self.reminders.refresh_reminders)
        self.add_reminder_window.reminder_added.connect(self.dashboard.refresh_dashboard)
        self.add_reminder_window.show()

    def open_add_event_window(self):
        self.add_event_window = AddEventWindow(self.user_id)
        self.add_event_window.event_added.connect(self.events.refresh_events)
        self.add_event_window.show()

    def open_add_measurement_window(self):
        self.add_measurement_window = AddMeasurementWindow(self.user_id)
        self.add_measurement_window.measurement_added.connect(self.measurements.refresh_measurements)
        self.add_measurement_window.show()

    def open_add_photo_window(self):
        self.add_photo_window = AddPhotoWindow(self.user_id)
        self.add_photo_window.photo_added.connect(self.gallery.load_photos)
        self.add_photo_window.show()
    
