CREATE TABLE korisnik (
    id SERIAL PRIMARY KEY,
    ime VARCHAR(255) NOT NULL,
    email VARCHAR(255) NOT NULL UNIQUE,
    password TEXT NOT NULL
);

CREATE TABLE biljka (
    id SERIAL PRIMARY KEY,
    naziv VARCHAR(255) NOT NULL,
    opis TEXT,
    vrsta VARCHAR(255),
    datum_dodavanja TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
);

CREATE TABLE mjerenje_izvor (
    id SERIAL PRIMARY KEY,
    biljka_id INT REFERENCES biljka(id),
    korisnik_id INT REFERENCES korisnik(id),
    izvor VARCHAR(255) NOT NULL,
    temperatura FLOAT,
    vlaga FLOAT,
    svjetlost FLOAT,
    datum_mjerenja TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE podsjetnik (
    id SERIAL PRIMARY KEY,
    biljka_id INT REFERENCES biljka(id),
    naziv VARCHAR(255) NOT NULL,
    datum_podsjetnika TIMESTAMP NOT NULL,
    ponavljajuci BOOLEAN DEFAULT FALSE,
    ponavljanje_interval INTEGER,
    ponavljanje_jedinica TEXT
);

CREATE TABLE dogadjaj (
    id SERIAL PRIMARY KEY,
    biljka_id INT REFERENCES biljka(id),
    naziv VARCHAR(255) NOT NULL,
    opis TEXT,
    datum_dogadjaja TIMESTAMP NOT NULL
);

CREATE TABLE slika (
    id SERIAL PRIMARY KEY,
    biljka_id INT REFERENCES biljka(id),
    dogadjaj_id INTEGER REFERENCES dogadjaj(id),
    url TEXT NOT NULL,
    datum_dodavanja TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE postavke_mjerenja (
    id SERIAL PRIMARY KEY,
    biljka_id INT REFERENCES biljka(id),
    interval_mjerenja INT NOT NULL,
    datum_postavljanja TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE biljka_korisnik (
    id SERIAL PRIMARY KEY,
    korisnik_id INT REFERENCES korisnik(id),
    biljka_id INT REFERENCES biljka(id),
    uloga VARCHAR(255) NOT NULL
);

CREATE OR REPLACE FUNCTION trg_sprijeci_duple_korisnike_fn()
RETURNS TRIGGER AS $$
BEGIN
    IF EXISTS (
        SELECT 1
        FROM biljka_korisnik
        WHERE korisnik_id = NEW.korisnik_id
        AND biljka_id = NEW.biljka_id
    ) THEN
        RAISE EXCEPTION 'User already assigned to this plant';
    END IF;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trg_sprijeci_duple_korisnike
BEFORE INSERT ON biljka_korisnik
FOR EACH ROW
EXECUTE FUNCTION trg_sprijeci_duple_korisnike_fn();

CREATE OR REPLACE FUNCTION trg_podsjetnik_buducnost_fn()
RETURNS TRIGGER AS $$
BEGIN
    IF NEW.datum_podsjetnika < NOW() THEN
        RAISE EXCEPTION 'Cannot insert reminder in the past';
    END IF;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trg_podsjetnik_buducnost
BEFORE INSERT ON podsjetnik
FOR EACH ROW
EXECUTE FUNCTION trg_podsjetnik_buducnost_fn();

CREATE OR REPLACE FUNCTION trg_mjerenje_interval_fn()
RETURNS TRIGGER AS $$
DECLARE
    interval_hours DOUBLE PRECISION;
BEGIN
    SELECT interval_mjerenja INTO interval_hours
    FROM postavke_mjerenja
    WHERE biljka_id = NEW.biljka_id
    ORDER BY datum_postavljanja DESC
    LIMIT 1;

    IF NEW.izvor = 'senzor' AND interval_hours IS NULL THEN
        RAISE EXCEPTION 'Measurement interval not set for this plant';
    END IF;

    IF NEW.izvor = 'senzor' THEN
        IF EXISTS (
            SELECT 1
            FROM mjerenje_izvor
            WHERE biljka_id = NEW.biljka_id
              AND izvor = 'senzor'
              AND datum_mjerenja > NOW() - INTERVAL '1 hour' * interval_hours
        ) THEN
            RAISE EXCEPTION 'Cannot insert new sensor measurement within the defined interval';
        END IF;
    END IF;

    RETURN NEW;
END;
$$ LANGUAGE plpgsql;


CREATE TRIGGER trg_mjerenje_interval
BEFORE INSERT ON mjerenje_izvor
FOR EACH ROW
EXECUTE FUNCTION trg_mjerenje_interval_fn();

ALTER TABLE postavke_mjerenja
  ADD CONSTRAINT uniq_postavke_biljka UNIQUE(biljka_id);

ALTER TABLE postavke_mjerenja
    ALTER COLUMN interval_mjerenja
    TYPE DOUBLE PRECISION
    USING interval_mjerenja::DOUBLE PRECISION;

ALTER TABLE biljka
ADD COLUMN aktivna BOOLEAN DEFAULT TRUE;
ADD COLUMN datum_deaktivacije TIMESTAMP;