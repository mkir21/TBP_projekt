from PyQt5.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel, QComboBox,
    QListWidget, QCalendarWidget, QGroupBox, QToolTip, QPushButton
)
from PyQt5.QtCore import QDate
from PyQt5.QtGui import QColor, QTextCharFormat, QCursor
import datetime
# optional matplotlib imports
from matplotlib.backends.backend_qt5agg import FigureCanvasQTAgg as FigureCanvas
from matplotlib.figure import Figure
from db import get_db_connection
from utils import fetch_plants
from reminders import AddReminderWindow

class DashboardWidget(QWidget):
    def __init__(self, user_id):
        super().__init__()
        self.user_id = user_id
        self.metric_map = {
            "Temperature": "temperatura",
            "Moisture":    "vlaga",
            "Light":       "svjetlost"
        }
        self.current_metric = "Temperature"    # default
        self.load_plants()
        self.current_plant_index = 0
        self.initUI()

    def load_plants(self):
        """Load all plants for this user (uses utils.fetch_plants)."""
        all_plants = fetch_plants(self.user_id)
        # we only need id & naziv here
        self.plants = [{'id': p['id'], 'naziv': p['naziv']} for p in all_plants]

    def initUI(self):
        main_layout = QVBoxLayout(self)
        top_layout  = QHBoxLayout()

        # — Left: Reminders + graph (only once!) —
        self.reminder_list = QListWidget()
        self.reminder_list.setMaximumHeight(120)
        for item in self.get_upcoming_reminders(limit=5):
            self.reminder_list.addItem(item)

        self.metric_combo = QComboBox()
        self.metric_combo.addItems(self.metric_map.keys())
        self.metric_combo.setCurrentText(self.current_metric)
        self.metric_combo.currentTextChanged.connect(self._on_metric_changed)

        nav = QHBoxLayout()
        self.prev_btn = QPushButton("←"); self.next_btn = QPushButton("→")
        self.prev_btn.clicked.connect(self._show_prev_plant)
        self.next_btn.clicked.connect(self._show_next_plant)
        nav.addWidget(self.prev_btn); nav.addWidget(self.next_btn)

        self.figure = Figure(figsize=(6,3))
        self.canvas = FigureCanvas(self.figure)

        reminders_group = QGroupBox("Upcoming Reminders")
        rem_layout      = QVBoxLayout()
        rem_layout.addWidget(self.reminder_list)
        rem_layout.addWidget(self.metric_combo)
        rem_layout.addLayout(nav)
        rem_layout.addWidget(self.canvas, stretch=1)
        reminders_group.setLayout(rem_layout)
        top_layout.addWidget(reminders_group, stretch=1)

        # — Right: Calendar —
        calendar_group = QGroupBox("Calendar")
        cal_layout     = QVBoxLayout()
        self.calendar  = QCalendarWidget()
        self.calendar.clicked.connect(self.show_reminders_for_date)
        cal_layout.addWidget(self.calendar)
        calendar_group.setLayout(cal_layout)
        top_layout.addWidget(calendar_group, stretch=1)

        self._highlight_reminder_dates()

        # only add top_layout once
        main_layout.addLayout(top_layout)

        # — Summary —
        summary_group = QGroupBox("Summary (Last 7 Days)")
        sum_layout    = QHBoxLayout()
        self.lbl_plants       = QLabel()
        self.lbl_events       = QLabel()
        self.lbl_measurements = QLabel()
        sum_layout.addWidget(self.lbl_plants)
        sum_layout.addWidget(self.lbl_events)
        sum_layout.addWidget(self.lbl_measurements)
        summary_group.setLayout(sum_layout)

        # ← DELETE this duplicate:
        # main_layout.addLayout(top_layout)

        main_layout.addWidget(summary_group)

        self.setStyleSheet("""
            QGroupBox { font-weight: bold; margin-top: 10px; }
            QLabel    { padding: 4px; }
        """)

        self.refresh_dashboard()

    def _on_metric_changed(self, metric_label):
        self.current_metric = metric_label
        self._plot_plant_graph()
        self._update_nav_buttons()

    def get_upcoming_reminders(self, limit):
        conn = get_db_connection()
        cur = conn.cursor()
        now = datetime.datetime.now()
        cur.execute(
            """
            SELECT p.naziv      AS plant_name,
                   pod.naziv    AS reminder_title,
                   pod.datum_podsjetnika
              FROM podsjetnik pod
              JOIN biljka p ON pod.biljka_id = p.id
              JOIN biljka_korisnik bk ON p.id = bk.biljka_id
             WHERE bk.korisnik_id = %s
               AND pod.datum_podsjetnika >= %s
             ORDER BY pod.datum_podsjetnika ASC
             LIMIT %s
            """,
            (self.user_id, now, limit)
        )
        items = []
        for plant_name, title, dt in cur.fetchall():
            items.append(f"{dt.strftime('%Y-%m-%d %H:%M')} – {plant_name}: {title}")
        cur.close()
        conn.close()
        return items

    def get_reminder_dates(self):
        """Return list of date objects for all future reminders."""
        conn = get_db_connection()
        cur = conn.cursor()
        today = datetime.date.today()
        cur.execute(
            """
            SELECT DISTINCT DATE(datum_podsjetnika)
              FROM podsjetnik pod
              JOIN biljka_korisnik bk ON pod.biljka_id = bk.biljka_id
             WHERE bk.korisnik_id = %s
               AND pod.datum_podsjetnika::date >= %s
            """,
            (self.user_id, today)
        )
        dates = [row[0] for row in cur.fetchall()]
        cur.close()
        conn.close()
        return dates
    
    def _highlight_reminder_dates(self):
        fmt = QTextCharFormat()
        fmt.setBackground(QColor("lightgreen"))
        for d in self.get_reminder_dates():
            qd = QDate(d.year, d.month, d.day)
            self.calendar.setDateTextFormat(qd, fmt)

    def get_reminders_for_date(self, date):
        """Fetch all reminders on a given date."""
        conn = get_db_connection()
        cur = conn.cursor()
        cur.execute(
            """
            SELECT p.naziv, pod.naziv, pod.datum_podsjetnika
              FROM podsjetnik pod
              JOIN biljka p ON pod.biljka_id = p.id
              JOIN biljka_korisnik bk ON p.id = bk.biljka_id
             WHERE bk.korisnik_id = %s
               AND pod.datum_podsjetnika::date = %s
             ORDER BY pod.datum_podsjetnika
            """,
            (self.user_id, date)
        )
        items = [
            f"{dt.strftime('%H:%M')} – {plant}: {title}"
            for plant, title, dt in cur.fetchall()
        ]
        cur.close()
        conn.close()
        return items

    def show_reminders_for_date(self, qdate):
        """Show a tooltip listing all reminders for the clicked date."""
        date = qdate.toPyDate()
        reminders = self.get_reminders_for_date(date)
        if reminders:
            text = "\n".join(reminders)
            QToolTip.showText(QCursor.pos(), text, self.calendar)

    def get_plants_count(self):
        conn = get_db_connection()
        cur = conn.cursor()
        cur.execute(
            "SELECT COUNT(*) "
            "  FROM biljka_korisnik "
            " WHERE korisnik_id = %s",
            (self.user_id,)
        )
        count = cur.fetchone()[0]
        cur.close()
        conn.close()
        return count

    def get_events_count(self):
        conn = get_db_connection()
        cur = conn.cursor()
        week_ago = datetime.date.today() - datetime.timedelta(days=7)
        cur.execute(
            "SELECT COUNT(*) "
            "  FROM dogadjaj d "
            "  JOIN biljka_korisnik bk ON d.biljka_id = bk.biljka_id "
            " WHERE bk.korisnik_id = %s "
            "   AND d.datum_dogadjaja >= %s",
            (self.user_id, week_ago)
        )
        count = cur.fetchone()[0]
        cur.close()
        conn.close()
        return count
    
    def get_measurements_count(self):
        """Count all measurements in the last 7 days for this user."""
        conn = get_db_connection()
        cur = conn.cursor()
        week_ago = datetime.date.today() - datetime.timedelta(days=7)
        cur.execute(
            """
            SELECT COUNT(*)
              FROM mjerenje_izvor m
              JOIN biljka_korisnik bk ON m.biljka_id = bk.biljka_id
             WHERE bk.korisnik_id = %s
               AND m.datum_mjerenja >= %s
            """,
            (self.user_id, week_ago)
        )
        count = cur.fetchone()[0]
        cur.close()
        conn.close()
        return count

    def get_measurements_for_plant(self, plant_id, limit=10, metric_col=None):
        """
        Returns two lists (timestamps, values) for the last `limit`
        measurements of a given plant and given metric.
        """
        col = metric_col or self.metric_map[self.current_metric]
        conn = get_db_connection()
        cur = conn.cursor()
        # safe: col comes from fixed mapping
        cur.execute(f"""
            SELECT m.datum_mjerenja, m.{col}
              FROM mjerenje_izvor m
              JOIN biljka_korisnik bk ON m.biljka_id = bk.biljka_id
             WHERE bk.korisnik_id = %s
               AND m.biljka_id = %s
             ORDER BY m.datum_mjerenja DESC
             LIMIT %s
        """, (self.user_id, plant_id, limit))
        rows = cur.fetchall()
        cur.close()
        conn.close()

        rows.reverse()
        dates = [r[0] for r in rows]
        values= [r[1] for r in rows]
        return dates, values
    
    def _update_nav_buttons(self):
        self.prev_btn.setEnabled(self.current_plant_index > 0)
        self.next_btn.setEnabled(self.current_plant_index < len(self.plants) - 1)

    def _show_prev_plant(self):
        if self.current_plant_index > 0:
            self.current_plant_index -= 1
            self._plot_plant_graph()
            self._update_nav_buttons()

    def _show_next_plant(self):
        if self.current_plant_index < len(self.plants) - 1:
            self.current_plant_index += 1
            self._plot_plant_graph()
            self._update_nav_buttons()

    def _plot_sample_graph(self):
        ax = self.figure.add_subplot(111)
        data = [5, 8, 6, 9, 7]  # placeholder readings
        ax.plot(data, marker='o')
        ax.set_title("Sample Measurements")
        self.canvas.draw()

    def _plot_plant_graph(self):
        self.figure.clear()
        ax = self.figure.add_subplot(111)

        if not self.plants:
            ax.text(.5, .5, "No plants", ha="center", va="center")
        else:
            plant = self.plants[self.current_plant_index]
            dates, values = self.get_measurements_for_plant(
                plant['id'], limit=10, metric_col=self.metric_map[self.current_metric]
            )
            if dates and values:
                ax.plot(dates, values, marker='o', linestyle='-')
                ax.set_title(f"{plant['naziv']} ({self.current_metric.lower()})")
                ax.set_xticklabels(
                    [d.strftime("%m-%d") for d in dates],
                    rotation=45, ha='right'
                )
            else:
                ax.text(.5, .5, "No data", ha="center", va="center")

        self.canvas.draw()

    def _get_first_plant(self):
        """Return the first plant dict or None."""
        conn = get_db_connection()
        cur = conn.cursor()
        cur.execute(
            """
            SELECT p.id, p.naziv
              FROM biljka p
              JOIN biljka_korisnik bk ON p.id = bk.biljka_id
             WHERE bk.korisnik_id = %s
             ORDER BY p.datum_dodavanja ASC
             LIMIT 1
            """,
            (self.user_id,)
        )
        row = cur.fetchone()
        cur.close()
        conn.close()
        if row:
            return {'id': row[0], 'naziv': row[1]}
        return None

    
    def refresh_dashboard(self):
        # 1) Reminders list
        self.reminder_list.clear()
        for item in self.get_upcoming_reminders(limit=5):
            self.reminder_list.addItem(item)

        # 2) Calendar highlights
        self._highlight_reminder_dates()

        # 3) Summary labels
        self.lbl_plants.setText(f"Plants: {self.get_plants_count()}")
        self.lbl_events.setText(f"Events: {self.get_events_count()}")
        self.lbl_measurements.setText(f"Measurements: {self.get_measurements_count()}")

        # 4) Graph & nav buttons
        self._plot_plant_graph()
        self._update_nav_buttons()
