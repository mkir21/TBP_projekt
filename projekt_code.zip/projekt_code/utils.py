import os
import requests
from PyQt5.QtWidgets import QLabel
from PyQt5.QtCore import Qt, pyqtSignal
from PyQt5.QtGui import QPixmap
from db import get_db_connection

def load_plant_pixmap(plant_id):
    pixmap = QPixmap()
    try:
        conn = get_db_connection(); cur = conn.cursor()
        cur.execute(
            "SELECT url FROM slika WHERE biljka_id = %s "
            "ORDER BY datum_dodavanja DESC LIMIT 1",
            (plant_id,)
        )
        row = cur.fetchone()
        cur.close(); conn.close()

        if row:
            url = row[0]
            if os.path.isfile(url):
                pixmap.load(url)
            else:
                resp = requests.get(url); resp.raise_for_status()
                pixmap.loadFromData(resp.content)
    except:
        pass

    if pixmap.isNull():
        pixmap = QPixmap(os.path.join(os.path.dirname(__file__), "../logo.png"))
    return pixmap

def fetch_plants(user_id):
    """
    Returns a list of dicts:
      [{'id':…, 'naziv':…, 'opis':…}, …]
    """
    conn = get_db_connection()
    cur  = conn.cursor()
    cur.execute("""
        SELECT p.id, p.naziv, p.opis
          FROM biljka p
          JOIN biljka_korisnik bk ON p.id = bk.biljka_id
         WHERE bk.korisnik_id = %s
         ORDER BY p.datum_dodavanja ASC
    """, (user_id,))
    plants = [
      {'id': pid, 'naziv': naziv, 'opis': opis}
      for pid, naziv, opis in cur.fetchall()
    ]
    cur.close()
    conn.close()
    return plants

def fetch_recent_photos(user_id, limit=100):
    """
    Returns a list of dicts:
      [{'filepath':…, 'date_added':…, 'plant_id':…, 'plant_name':…}, …]
    """
    conn = get_db_connection()
    cur  = conn.cursor()
    cur.execute("""
        SELECT s.url, s.datum_dodavanja, s.biljka_id, p.naziv
        FROM slika s
        JOIN biljka p ON p.id = s.biljka_id
        JOIN biljka_korisnik bk ON bk.biljka_id = p.id
        WHERE bk.korisnik_id = %s
        ORDER BY s.datum_dodavanja DESC LIMIT %s
    """, (user_id, limit))
    photos = [
      {'filepath': url,
       'date_added': date,
       'plant_id': pid,
       'plant_name': name}
      for url, date, pid, name in cur.fetchall()
    ]
    cur.close()
    conn.close()
    return photos

class ClickableLabel(QLabel):
    clicked = pyqtSignal()

    def __init__(self, parent=None):
        super().__init__(parent)
        # ↳ set the hand‐pointer cursor here:
        self.setCursor(Qt.PointingHandCursor)
        # remove `cursor: pointer;` from the stylesheet
        self.setStyleSheet("""
            QLabel {
                font-size: 22px;
                padding: 10px;
            }
            QLabel:hover {
                color: blue;
                text-decoration: underline;
            }
        """)

    def mousePressEvent(self, event):
        self.clicked.emit()