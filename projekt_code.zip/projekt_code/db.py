import os
import psycopg2

def get_db_connection():
    """Reads connection params from the ENV and returns a new psycopg2 connection."""
    return psycopg2.connect(
        dbname   = os.getenv("DB_NAME",   "biljke"),
        user     = os.getenv("DB_USER",   "marko"),
        password = os.getenv("DB_PASSWORD","vjezbe"),
        host     = os.getenv("DB_HOST",   "localhost"),
        port     = os.getenv("DB_PORT",   "5432")
    )