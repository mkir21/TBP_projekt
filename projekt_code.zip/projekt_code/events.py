from PyQt5.QtWidgets import (QWidget, QVBoxLayout, QHBoxLayout, QLineEdit,
                             QComboBox, QPushButton, QTableWidget,
                             QTableWidgetItem, QScrollArea, QLabel, QDialog,
                             QTextEdit, QMessageBox, QFileDialog, QDateTimeEdit)
from PyQt5.QtCore import Qt, pyqtSignal
from PyQt5.QtGui import QPixmap
from datetime import datetime
from utils import load_plant_pixmap, fetch_plants
from db import get_db_connection

class EventsWidget(QWidget):
    def __init__(self, user_id, mainwindow):
        super().__init__()
        self.user_id = user_id
        self.mainwindow = mainwindow
        self.stacked = mainwindow.stacked_widget
        self.initUI()
 

    def initUI(self):
        self.setWindowTitle('Dogadaji')
        v = QVBoxLayout(self)

        # search + sort + add button
        h = QHBoxLayout()
        self.search = QLineEdit(self); self.search.setPlaceholderText("Traži…")
        self.search.textChanged.connect(self.apply_filter)
        h.addWidget(self.search)

        self.sort = QComboBox(self)
        self.sort.addItems(["Datum ↑","Datum ↓","Naziv A-Z","Naziv Z-A"])
        self.sort.currentIndexChanged.connect(self.apply_sort)
        h.addWidget(self.sort)

        btn = QPushButton("Dodaj dogadaj", self)
        # call the MainWindow method directly
        btn.clicked.connect(self.mainwindow.open_add_event_window)
        h.addWidget(btn)

        v.addLayout(h)

        # table
        self.table = QTableWidget(self)
        self.table.setColumnCount(2)
        self.table.setHorizontalHeaderLabels(["Datum","Naziv"])
        self.table.horizontalHeader().setStretchLastSection(True)
        self.table.setEditTriggers(QTableWidget.NoEditTriggers)
        self.table.cellDoubleClicked.connect(self.open_detail)
        v.addWidget(self.table)

        self.refresh_events()

    def refresh_events(self):
        self.items = self.fetch_events()
        self.apply_filter()

    def fetch_events(self):
        out=[]
        conn = get_db_connection(); cur=conn.cursor()
        cur.execute("""
          SELECT d.id,d.naziv,d.datum_dogadjaja
            FROM dogadjaj d
            JOIN biljka_korisnik bk ON d.biljka_id=bk.biljka_id
           WHERE bk.korisnik_id=%s
           ORDER BY d.datum_dogadjaja
        """,(self.user_id,))
        for eid,name,dt in cur.fetchall():
            out.append({'id':eid,'naziv':name,'datum':dt})
        cur.close(); conn.close()
        return out

    def apply_filter(self):
        term=self.search.text().lower()
        rows = [e for e in self.items if term in e['naziv'].lower()]
        self.table.setRowCount(len(rows))
        for r,e in enumerate(rows):
            self.table.setItem(r, 0, QTableWidgetItem(e['datum'].strftime("%Y-%m-%d")))
            self.table.setItem(r, 1, QTableWidgetItem(e['naziv']))
        self.apply_sort()

    def apply_sort(self):
        idx=self.sort.currentIndex()
        if idx==0: col,order=0,Qt.AscendingOrder
        elif idx==1: col,order=0,Qt.DescendingOrder
        elif idx==2: col,order=1,Qt.AscendingOrder
        else:        col,order=1,Qt.DescendingOrder
        self.table.sortItems(col,order)

    def open_detail(self,row,_col):
        eid = self.items[row]['id']
        detail = EventDetailWidget(eid, self)
        self.stacked.addWidget(detail)
        self.stacked.setCurrentWidget(detail)


class AddEventWindow(QWidget):
    event_added = pyqtSignal()
    def __init__(self,user_id):
        super().__init__()
        self.user_id=user_id
        self.pics=[]
        self.initUI()

    def initUI(self):
        self.setWindowTitle("Dodaj dogadaj")
        v=QVBoxLayout(self)
        v.addWidget(QLabel("Biljka:",self))
        self.plant_combo = QComboBox(self)
        for p in fetch_plants(self.user_id):
            self.plant_combo.addItem(p['naziv'], p['id'])
        v.addWidget(self.plant_combo)
        v.addWidget(QLabel("Naziv:",self))
        self.name=QLineEdit(self); v.addWidget(self.name)
        v.addWidget(QLabel("Opis:",self))
        self.desc=QTextEdit(self); v.addWidget(self.desc)
        v.addWidget(QLabel("Datum:",self))
        self.dt=QDateTimeEdit(datetime.now(),self)
        self.dt.setDisplayFormat("yyyy-MM-dd HH:mm")
        v.addWidget(self.dt)
        btn_pic=QPushButton("Dodaj slike…",self)
        btn_pic.clicked.connect(self.select_pics)
        v.addWidget(btn_pic)
        btn=QPushButton("Spremi",self)
        btn.clicked.connect(self.save)
        v.addWidget(btn)

    def select_pics(self):
        files, _ = QFileDialog.getOpenFileNames(self, "Odaberi slike","","Images (*.png *.jpg)")
        if files: self.pics.extend(files)

    def save(self):
        pid = self.plant_combo.currentData()
        name=self.name.text().strip()
        desc=self.desc.toPlainText().strip()
        dt=self.dt.dateTime().toPyDateTime()
        if not name:
            QMessageBox.warning(self,"Error","Unesite naziv"); return
        conn=get_db_connection(); cur=conn.cursor()
        cur.execute("""
          INSERT INTO dogadjaj(biljka_id,naziv,opis,datum_dogadjaja)
          VALUES(%s,%s,%s,%s) RETURNING id
        """,(pid,name,desc,dt))
        eid=cur.fetchone()[0]
        for url in self.pics:
            cur.execute("INSERT INTO slika(biljka_id,url,dogadjaj_id) VALUES(%s,%s,%s)",
                        (pid,url,eid))
        conn.commit(); cur.close(); conn.close()
        self.event_added.emit()
        self.close()


class EventDetailWidget(QWidget):
    def __init__(self,event_id,parent):
        super().__init__(parent)
        self.eid=event_id
        self.parent=parent
        self.user_id = parent.user_id 
        self.load()
        # set the layout once
        self.main_layout = QVBoxLayout(self)
        self.initUI()

    def load(self):
        conn=get_db_connection(); cur=conn.cursor()
        cur.execute("SELECT naziv,opis,datum_dogadjaja,biljka_id FROM dogadjaj WHERE id=%s",(self.eid,))
        self.name,self.desc,self.dt,self.pid=cur.fetchone()
        cur.execute("SELECT url FROM slika WHERE dogadjaj_id=%s",(self.eid,))
        self.pics=[r[0] for r in cur.fetchall()]
        cur.close(); conn.close()

    def initUI(self):
        # clear out previous widgets from the layout
        for i in reversed(range(self.main_layout.count())):
            item = self.main_layout.takeAt(i)
            w = item.widget()
            if w:
                w.deleteLater()

        self.setWindowTitle(self.name)
        v = self.main_layout

        #header
        v.addWidget(QLabel(f"{self.dt.strftime('%Y-%m-%d')} – <b>{self.name}</b>", self))

        # description
        desc_lbl = QLabel(self.desc, self)
        desc_lbl.setWordWrap(True)
        v.addWidget(desc_lbl)
        
        # --- Dodaj Edit / Delete gumbe ---
        hb = QHBoxLayout()
        btn_edit = QPushButton("Uredi događaj", self)
        btn_del  = QPushButton("Obriši događaj", self)
        btn_edit.clicked.connect(self.edit_event)
        btn_del.clicked.connect(self.delete_event)
        hb.addWidget(btn_edit); hb.addWidget(btn_del)
        v.addLayout(hb)

        # IMAGES
        scroll = QScrollArea(self)
        container = QWidget()
        hl = QHBoxLayout(container)

        # debug: print what URLs we actually have
        print("EventDetailWidget: pics =", self.pics)
        
        for url in self.pics:
            lbl = QLabel(self)
            pix = QPixmap()

            if url.startswith("http"):
                # if you really need to load remote images,
                # you’ll have to fetch them via requests/QNetwork, e.g.:
                try:
                    import requests
                    resp = requests.get(url)
                    pix.loadFromData(resp.content)
                except Exception as e:
                    print("  failed to download", url, e)
            else:
                # local‐file path
                if not pix.load(url):
                    print("  failed to load local file", url)

            if pix.isNull():
                lbl.setText("[Couldn’t load image]")
                lbl.setStyleSheet("color: red;")
            else:
                lbl.setPixmap(pix.scaledToWidth(150, Qt.SmoothTransformation))

            hl.addWidget(lbl)

        scroll.setWidget(container)
        scroll.setWidgetResizable(True)
        v.addWidget(scroll)

        # back button
        back = QPushButton("Nazad", self)
        back.clicked.connect(lambda: self.parent.stacked.setCurrentWidget(self.parent))
        v.addWidget(back)
    
    def edit_event(self):
        dlg = EditEventDialog(self.eid, self.user_id, self)
        dlg.event_updated.connect(self._on_updated)
        dlg.exec_()
    
    def delete_event(self):
        if QMessageBox.question(self, "Potvrda",
               "Jeste li sigurni da želite obrisati ovaj događaj?") != QMessageBox.Yes:
            return
        conn = get_db_connection(); cur = conn.cursor()
        cur.execute("DELETE FROM dogadjaj WHERE id = %s", (self.eid,))
        conn.commit(); cur.close(); conn.close()
        # refresh i vraćanje na listu
        self.parent.refresh_events()
        self.parent.stacked.setCurrentWidget(self.parent)

    def _on_updated(self):
        # nakon uređivanja, ponovno učitaj i osvježi detalje
        self.load()
        self.initUI()
        self.parent.refresh_events()

class EditEventDialog(QDialog):
    event_updated = pyqtSignal()

    def __init__(self, event_id, user_id, parent=None):
        super().__init__(parent)
        self.eid = event_id
        self.user_id = user_id
        self._load()
        self._build_ui()

    def _load(self):
        conn = get_db_connection(); cur = conn.cursor()
        cur.execute("SELECT biljka_id,naziv,opis,datum_dogadjaja FROM dogadjaj WHERE id=%s",
                    (self.eid,))
        self.pid, self.name, self.desc, self.dt = cur.fetchone()
        cur.close(); conn.close()

    def _build_ui(self):
        self.setWindowTitle("Uredi događaj")
        v = QVBoxLayout(self)
        v.addWidget(QLabel("Biljka:", self))
        self.plant = QComboBox(self)
        for p in fetch_plants(self.user_id):
            self.plant.addItem(p['naziv'], p['id'])
        self.plant.setCurrentIndex(self.plant.findData(self.pid))
        v.addWidget(self.plant)

        v.addWidget(QLabel("Naziv:", self))
        self.name_in = QLineEdit(self); self.name_in.setText(self.name)
        v.addWidget(self.name_in)

        v.addWidget(QLabel("Opis:", self))
        self.desc_in = QTextEdit(self); self.desc_in.setText(self.desc)
        v.addWidget(self.desc_in)

        v.addWidget(QLabel("Datum:", self))
        self.dt_in = QDateTimeEdit(self.dt, self)
        self.dt_in.setDisplayFormat("yyyy-MM-dd HH:mm")
        v.addWidget(self.dt_in)

        hb = QHBoxLayout()
        btn_save = QPushButton("Spremi", self)
        btn_cancel = QPushButton("Odustani", self)
        hb.addWidget(btn_save); hb.addWidget(btn_cancel)
        v.addLayout(hb)

        btn_save.clicked.connect(self._save)
        btn_cancel.clicked.connect(self.reject)

    def _save(self):
        name = self.name_in.text().strip()
        if not name:
            QMessageBox.warning(self, "Greška", "Naziv ne smije biti prazan")
            return
        pid  = self.plant.currentData()
        desc = self.desc_in.toPlainText().strip()
        dt   = self.dt_in.dateTime().toPyDateTime()
        try:
            conn = get_db_connection(); cur = conn.cursor()
            cur.execute("""
              UPDATE dogadjaj
                 SET biljka_id=%s, naziv=%s, opis=%s, datum_dogadjaja=%s
               WHERE id=%s
            """, (pid, name, desc, dt, self.eid))
            conn.commit(); cur.close(); conn.close()
            QMessageBox.information(self, "OK", "Događaj spremljen")
            self.event_updated.emit()
            self.accept()
        except Exception as e:
            QMessageBox.critical(self, "Error", str(e))
            if conn: conn.close()